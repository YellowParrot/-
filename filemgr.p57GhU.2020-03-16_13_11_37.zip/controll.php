
<?php
if (!isset($_SERVER['PHP_AUTH_USER'])) {
    header('WWW-Authenticate: Basic realm="You need to log in!"');
    header('HTTP/1.0 401 Unauthorized');
    echo '\n Ошибка 2, скажите Игорю';
    exit;
} else {
    if ($_SERVER['PHP_AUTH_USER'] == "admin" && $_SERVER['PHP_AUTH_PW'] == "admin"){
        
        $json = json_decode(file_get_contents('data.json'), true);
        
        if(!$json['data']['temperature']){
            $temp = 'Нет данных с датчика температуры';
        }
        else{
            
            $temp = $json['data']['temperature'];
        }
        
        
        if(!$json['data']['humidity']){
            $hum = 'Нет данных с датчика влажности';
        }
        else{
            $hum = $json['data']['humidity'];
        }
        
        
        
        if(!$json['data']['last_alarm']){
            $last = 'Нет данных!';
        }
        else if($json['data']['last_alarm'] == 'never'){
            $last = 'Тревоги еще не было';
        }
        else{
            $last = $json['data']['last_alarm'];
        }
        
        
        // 1 - включена
 
        $json['settings'] = [
          'signalisation_state' => $_GET['all'],
          'sms_state'          => $_GET['sms']
        ]; 
        file_put_contents('data.json', json_encode($json));

        
        echo "
                <html>
            	<head>
            		<title>Жёлтый попугай</title>
            		<meta charset='utf-8' />
            		<meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=no' />
            		<link rel='stylesheet' href='assets/css/main.css' />
            	</head>
            	<body class='is-preload'>
            
            		<!-- Header -->
            			<div id='header'>
            
            				<div class='top'>
            
            					<!-- Logo -->
            						<div id='logo'>
            							<span class='image avatar48'><img src='images/avatar.jpg' alt='' /></span>
            							<h1 id='title'>Жёлтый попугай</h1>
            							<p>школа 1569</p>
            						</div>
            
            					<!-- Nav -->
            						<nav id='nav'>
            							<ul>
            								<li><a href='index.php#top' id='top-link'><span class='icon solid fa-home'>Топ</span></a></li>
            								<li><a href='index.php#portfolio' id='portfolio-link'><span class='icon solid fa-th'>Галерея</span></a></li>
            								<li><a href='index.php#about' id='about-link'><span class='icon solid fa-user'>О нас</span></a></li>
            								<li><a href='index.php#contact' id='contact-link'><span class='icon solid fa-envelope'>Контакты</span></a></li>
            
            
            							</ul>
            						</nav>
            
            				</div>
            
            				<div class='bottom'>
            
            					<!-- Social Icons -->
            						<ul class='icons'>
            							<li><a href='https://yellowparrotlart@gmail.com' class='icon brands fa-google'><span class='label'>Google</span></a></li>
            							<li><a href='https://gihub.com/yellowparrot' class='icon brands fa-github'><span class='label'>Github</span></a></li>
            						</ul>
            
            				</div>
            
            			</div>
            
            		<!-- Main -->
            			<div id='main'>
            
            				<!-- Intro -->
            					<section id='view' >
            						<div class='container'>
            						
            						    <p align='left'>
                                            <b>Датчики</b><br>
                                                Температура:  $temp <br>
                                                Влажность:  $hum<br>
                                                Последняя тревога:  $last<br>
                                        </p>
            						    
            						    <table style='width: 100%; background-color: #D5D5D5;'>
                                        <tbody >
                                        <tr>
                                        <td style='width: 272.767px;'>Камера 1</td>
                                        <td style='width: 235.233px;'>Камера 2</td>
                                        </tr>
                                        <tr>
                                        <td style='width: 272.767px;'><img src='http://yellowparrot.tk/images/cam1.jpg' width='100%' /></td>
                                        <td style='width: 235.233px;'><img src='http://yellowparrot.tk/images/cam2.jpg' width='100%' /></td></td>
                                        </tr>
                                        </tbody>
                                        </table>
            
            						</div>
            					</section>
            					
            					<section id='controll'>
            						<div class='container'>
                                        
                                        
                                        
            							<form  action='#' method='GET'>
            							<label  class='switch'>
            							<br/>	Сигнализация
            							<input  name='all' type='checkbox'>
            							<span class='slider round'></span>
            							</label> 
            							
                                        <br>
            							<br>
            
            							<label  class='switch'>
            							<br/>	Смс
            							<input name='sms' type='checkbox'>
            							<span class='slider round'></span>
            							</label> 
            							
            							<br>
            							<br>
            							
            							<label  class='switch'>
            							<br/>1Камера
            							<input name='cam1' type='checkbox'>
            							<span class='slider round'></span>
            							</label> 
            							
            							<br>
            							<br>
            							
            							<label  class='switch'>
            							<br/>2Камера
            							<input name='cam2' type='checkbox'>
            							<span class='slider round'></span>
            							</label> 
            							
            							<br>
            							<br>
            							<br>
            							
            							<input type='reset'/>
            							
            							<input type='submit' value='Отправить'/>
            							
            							</form>
            
            						</div>
            					</section>
            
            			</div>
            			
            
            		<!-- Scripts -->
            			<script src='assets/js/jquery.min.js'></script>
            			<script src='assets/js/jquery.scrolly.min.js'></script>
            			<script src='assets/js/jquery.scrollex.min.js'></script>
            			<script src='assets/js/browser.min.js'></script>
            			<script src='assets/js/breakpoints.min.js'></script>
            			<script src='assets/js/util.js'></script>
            			<script src='assets/js/main.js'></script>
            
            	</body>
            
            	<style>
            				/* The switch - the box around the slider */
            		.switch {
            		position: relative;
            		display: inline-block;
            		width: 60px;
            		height: 34px;
            		}
            
            		/* Hide default HTML checkbox */
            		.switch input {
            		opacity: 0;
            		width: 0;
            		height: 0;
            		}
            
            		/* The slider */
            		.slider {
            		position: absolute;
            		cursor: pointer;
            		top: 0;
            		left: 0;
            		right: 0;
            		bottom: 0;
            		background-color: #ccc;
            		-webkit-transition: .4s;
            		transition: .4s;
            		}
            
            		.slider:before {
            		position: absolute;
            		content: '';
            		height: 26px;
            		width: 26px;
            		left: 4px;
            		bottom: 4px;
            		background-color: white;
            		-webkit-transition: .4s;
            		transition: .4s;
            		}
            
            		input:checked + .slider {
            		background-color: #2196F3;
            		}
            
            		input:focus + .slider {
            		box-shadow: 0 0 1px #2196F3;
            		}
            
            		input:checked + .slider:before {
            		-webkit-transform: translateX(26px);
            		-ms-transform: translateX(26px);
            		transform: translateX(26px);
            		}
            
            		/* Rounded sliders */
            		.slider.round {
            		border-radius: 34px;
            		}
            
            		.slider.round:before {
            		border-radius: 50%;
            		} 
            	</style>
            </html>
        ";
        
      
        
       
    
        

    }
    
    else{
        echo "Неверный логин или пароль. Авторизуйтесь повторно";
        header('WWW-Authenticate: Basic realm="UNCORECT LOGIN OR PASSWORD"');
        header('HTTP/1.0 401 Unauthorized');
        echo '\n Ошибка 2, скажите Игорю';
        exit;
    }
}
?>


<!DOCTYPE HTML>
