<html>
	<head>
		<title>Жёлтый попугай</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="is-preload">

		<!-- Header -->
			<div id="header">

				<div class="top">

					<!-- Logo -->
						<div id="logo">
							<span class="image avatar48"><img src="images/avatar.jpg" alt="" /></span>
							<h1 id="title">Жёлтый попугай</h1>
							<p>школа 1569</p>
						</div>

					<!-- Nav -->
						<nav id="nav">
							<ul>
								<li><a href="#top" id="top-link"><span class="icon solid fa-home">Топ</span></a></li>
								<li><a href="#portfolio" id="portfolio-link"><span class="icon solid fa-th">Галерея</span></a></li>
								<li><a href="#about" id="about-link"><span class="icon solid fa-user">О нас</span></a></li>
								<li><a href="#contact" id="contact-link"><span class="icon solid fa-envelope">Контакты</span></a></li>
								<li><a href="controll.php" ><span class="icon solid fa-envelope">Панель управления</span></a></li>

							</ul>
						</nav>

				</div>

				<div class="bottom">

					<!-- Social Icons -->
						<ul class="icons">
							<li><a href='https://yellowparrotlart@gmail.com' class='icon brands fa-google'><span class='label'>Google</span></a></li>
							<li><a href='https://gihub.com/yellowparrot' class='icon brands fa-github'><span class='label'>Github</span></a></li>

						</ul>

				</div>

			</div>

		<!-- Main -->
			<div id="main">

				<!-- Intro -->
					<section id="top" style=' background: url("images/в.jpeg") no-repeat fixed;
    background-position: center center;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    min-height: 500px;'class="one dark cover">
						<div class="container">
                            
							<header>
								<h2 class="alt">Команда "Жёлтый попугай" <br /> Школа № <strong>1569 "Созвездие"</strong>.</h2>
								<p>Кейс №2 Проекта "Школа реальных дел"<br />
								Интелектуальная сисема охранная <br /> с удалённый управлением</p>
							</header>

							<footer>
								<a href="controll.php" id='conb'>Управление и просмотр</a>
								<style>
								    
                                #conb{
                                                                          display: inline-block;
                                                                          color: white;
                                                                          text-decoration: none;
                                                                          user-select: none;
                                                                          padding: .5em 2em;
                                                                          outline: none;
                                                                          border: 2px solid;
                                                                          border-radius: 1px;
                                                                          transition: 0.2s;
                                                                        }
                                                                   
                                                                    #conb:active { background: white; }   
                                        
								</style>
							</footer>

						</div>
					</section>

				<!-- Portfolio -->
					<section id="portfolio" class="two">
						<div class="container">

							<header>
								<h2>Галерея</h2>
							</header>

							<p>Было очень интересно заниматься этим проэктом. За время разработки 
								проиходило много веселых моментов, некоторые из которых поападали
								на камеру. Наша команда приобрела много опыта и новых навыков!</p>

							<div class="row">
								<div class="col-4 col-12-mobile">
									<article class="item">
										<a href="#" class="image fit"><img src="images/с4.jpg" alt="" /></a>
										<header>
											<h3>Это не бомба)</h3>
										</header>
									</article>
									<article class="item">
										<a href="#" class="image fit"><img src="images/confere.jpeg" alt="" /></a>
										<header>
											<h3>Обсуждаем концепт</h3>
										</header>
									</article>
								</div>
								<div class="col-4 col-12-mobile">
									<article class="item">
										<a href="#" class="image fit"><img src="images/esp.jpg" alt="" /></a>
										<header>
											<h3>Без неё никуда</h3>
										</header>
									</article>
									<article class="item">
										<a href="#" class="image fit"><img src="images/в.jpeg" alt="" /></a>
										<header>
											<h3>Разводим плату</h3>
										</header>
									</article>
								</div>
								<div class="col-4 col-12-mobile">
									<article class="item">
										<a href="#" class="image fit"><img src="images/print.jpg" alt="" /></a>
										<header>
											<h3>Печать крепления для камеры.</h3>
										</header>
									</article>
									<article class="item">
										<a href="#" class="image fit"><img src="images/sold.jpg" alt="" /></a>
										<header>
											<h3>Паяем платы</h3>
										</header>
									</article>
								</div>
							</div>

						</div>
					</section>

				<!-- About Me -->
					<section id="about" class="three">
						<div class="container">

							<header>
								<h2>О нас</h2>
							</header>

							<a href="#" class="image featured"><img src="images/team.jpg" alt="" /></a>

							<p>Наша команда состоит из четырех человек и конечно же предподавателя.<br />
								Предподаватель: Расюк Александр Викторович <br />
								Участники:<br />
								Кузьменков Игорь<br />
								Барченко Дмитрий<br />
								Гудков Даниил<br />
								Даниярбек Уллу Нурбол<br />

							</p>

						</div>
					</section>

				<!-- Contact -->
					<section id="contact" class="four">
						<div class="container">

							<header>
								<h2>Контакты</h2>
							</header>

							<p>
								Почта:   <a href='mailito:YellowParrotLart@gmail.com' >YellowParrotLart@gmail.com</a>.<br />
								Github:  <a href = "https://github.com/yellowparrot">github.com/yellowparrot</a><br />
								Телефон: <a href="tel:+7915142883">+7(915) 142-83-83</a>
							</p>

							

						</div>
					</section>

			</div>

		<!-- Footer -->
			

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>