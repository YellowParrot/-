<?php 

$json = json_decode(file_get_contents('data.json'), true);

/*
0 - закрыто 
1 - открыто
*/

$json['data'] = [
  'temperature' => (int)$_GET['temp'],
  'humidity'    => (int)$_GET['hum'],
  'win1'        => (int)$_GET['win1'],
  'win2'        => (int)$_GET['win2'],
  'door'        => (int)$_GET['door'],
  'last_alarm'  => $_GET['last']
];

foreach($json as $value)
{
    foreach($value as $value2)
        {
            echo $value2, "<br>";
        }
}


file_put_contents('data.json', json_encode($json));
?>